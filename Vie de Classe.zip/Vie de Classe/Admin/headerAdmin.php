<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="description" content="Ceci est un exemple de la description meta">
	<meta name="Viewport" content="width=device-witdh, initial-scale=1">
	<title>
		Bonjour
	</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	<script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>

	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

	<header>
		<nav class="navbar navbar-expand-md navbar-light bg-light">
			<div class="navbar-header">
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    				<span class="navbar-toggler-icon"></span>
  				</button>
			
			
  			<div class="collapse navbar-collapse" id="navbarSupportedContent">
    			<ul class="navbar-nav mr-auto">
      				<li class="nav-item active">
        				<a class="nav-link" href="index.php"> Accueil <span class="sr-only">Accueil</span></a>
      				</li>
					<?php 
						if (isset($_SESSION['userId'])) {
							echo '<li class="nav-item dropdown">
                				<a class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Vie De Classe
                				</a>
                				<div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  					<a class="dropdown-item" href="login.php">Emploi du Temps</a>
                  					<a class="dropdown-item" href="signup.php">Cahier de Texte</a>
                  					<a class="dropdown-item" href="signup.php">Bulletin</a>
                 					<a class="dropdown-item" href="signup.php">Dossiers partagés</a>';
						}
					?>
      				<li class="nav-item dropdown">
        				<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          					Mon compte
        				</a>
        				<div class="dropdown-menu" aria-labelledby="navbarDropdown">
      						<?php 
								if (!isset($_SESSION['userId'])) {
								 	echo '<a class="dropdown-item" href="login.php">Connexion</a>
          								<a class="dropdown-item" href="signup.php">Inscription</a>';
								} 
								else if (isset($_SESSION['userId'])) {
									echo '<a class="dropdown-item" href="#">Profil</a>
          								<a class="dropdown-item" href="#">Paramètres</a>
          								<div class="dropdown-divider"></div>
          								<a class="dropdown-item" href="includes/logout.inc.php">Déconnexion</a>';
								}	
							?>
        				</div>
      				</li>
    			</ul>
  			</div>
  		</div>
		</nav>
	</header>

</body>
</html>