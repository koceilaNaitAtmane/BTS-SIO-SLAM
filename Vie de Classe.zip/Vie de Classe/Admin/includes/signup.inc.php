<?php

#script de la création de compte

if (isset($_POST["btn-signup"])) {
 	
 	require "dbh.inc.php";

 	$username =$_POST["uid"];
 	$email =$_POST["mail"];
 	$password =$_POST["pwd"];
 	$passwordRepeat =$_POST["pwd-repeat"];


 	# Vérification des champs 
 	if (empty($username) || empty($email) || empty($password) || empty($passwordRepeat)) {
 		header("Location: ../signup.php?error=emptyfields");
 		exit();

 	}

else if (!filter_var($email, FILTER_VALIDATE_EMAIL) && !preg_match("/^[a-zA-Z0-9]*$/",$username)) {
   		header("Location: ../signup.php?error=invalidmail");
	}

#Vérification que l'adresse email est valide avec la fonction filter_validate_email
 else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  		header("Location: ../signup.php?error=invalidmail&uid=" .$username);
 		exit();
 	}
#Vérification de l'Username
else if (!preg_match("/^[a-zA-Z0-9]*$/",$username)) {
  		header("Location: ../signup.php?error=invalidusername&mail=" .$email);
 		exit();
 	}
 #Vérification du mot de passe
 else if ($password !== $passwordRepeat) {
 	header("Location: ../signup.php?error=passwordcheck&uid=" .$username. "&mail=" .$email);
 	exit();
 	}

 else {

 	#Compte existant ou non
 	$sql = "SELECT uid_Users FROM users WHERE uid_Users=?";

 	$stmt = mysqli_stmt_init($conn);

 	#Si la connection ne s'établit pas, message d'erreur
 	if (!mysqli_stmt_prepare($stmt, $sql)) {
 		header("Location: ../signup.php?error=sqlerror");
 		exit();
 	}
 	else{
 		#On vérifie si le compte est déjà existant
 		mysqli_stmt_bind_param($stmt, "s", $username);
 		mysqli_stmt_execute($stmt);
 		mysqli_stmt_store_result($stmt);
 		$resultCheck = mysqli_stmt_num_rows($stmt);

 		#Si le compte est existant, renvoi vers la page de création de compte
 		if ($resultCheck>0) {
  		header("Location: ../signup.php?error=usertaken&mail=" .$email);
 		exit();
 		}

 		else{

 			#Création du compte dans la base de données
 			$sql ="INSERT INTO users (uid_Users, email_Users, pwd_Users) VALUES (?, ?, ?)";
 			$stmt = mysqli_stmt_init($conn);

 			if (!mysqli_stmt_prepare($stmt, $sql)) {
 				header("Location: ../signup.php?error=sqlerror");
 				exit();
 			}

 			else{
 				#Cryptage du mot de passe dans le base de données
 				$hashedPwd = password_hash($password, PASSWORD_DEFAULT);

 				mysqli_stmt_bind_param($stmt, "sss", $username, $email, $hashedPwd );
 				mysqli_stmt_execute($stmt);
 				mysqli_stmt_store_result($stmt);
 				 header("Location: ../signup.php?signup=success");
 				exit();
			}

 		}

 	}

 }


# fermeture de la base de données
 mysqli_stmt_close($stmt);
 mysqli_close($conn);

 }

 else {

 	header("Location: ../signup.php");
 	exit();

 }