<?php

$servername = "localhost";
$dBUsername = "root";
$dbPassword="";
$dbName ="db_gestion_ecole";

$conn = mysqli_connect($servername, $dBUsername, $dbPassword, $dbName);

if (!$conn) {
	die("Connection échoué :" .mysqli_connect_error());
}