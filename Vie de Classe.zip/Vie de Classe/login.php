<header>
<?php
	require "header.php";
?>
</header>

	<body>
	<main>
		<?php 
			if (isset($_GET['error'])) {
				if ($_GET['error'] == "emptyfields") {
					echo "<p> Remplissez tous les champs.</p>";
				}
				else if ($_GET['error'] == "wrongpwd") {
					echo "<p> Mot de passe incorrect.</p>";
				}
				else if ($_GET['error'] == "nouser") {
					echo "<p> Aucun compte créé à ce nom.</p>";
				}
			}

		 ?>

    <div style="margin: auto; width: 30%; text-align: center;"  >
    	<h2>Connexion</h2>
		<form action="includes/login.inc.php" method="post">
  			<div class="form-group">
    			<h4><label for="userId">Username/E-mail</label></h4>
    			<input type="text" class="form-control" name="mailid">
  			</div>
  			<div class="form-group">
    			<h4><label for="pwd">Mot de Passe:</label></h4>
    			<input type="password" class="form-control" name="mdp">
  			</div>
  			<button type="submit" class="btn btn-primary btn-block" name="btn-login">Confirmer</button>
		</form>
	</div>
	</main>
	</body>

<footer>
<?php
	require "footer.php";
?>
</footer>