<!DOCTYPE html>
<html>
	<header>
		<?php
			require "header.php";
		?>
		
	</header>
	<body>
		<main>
			<?php 


				if (isset($_SESSION['userId'])) {
					if ($_SESSION['userId']==4) {
						require "Admin/indexAdmin.php";
					}
					else
						require "Utilisateur/indexUser.php";
				}
				else{
					echo '<p>You are logged out.</p>';
				}
			?>		
		</main>

		<footer>
			<?php
				require "footer.php";
			?>
		</footer>

	</body>
<html>

